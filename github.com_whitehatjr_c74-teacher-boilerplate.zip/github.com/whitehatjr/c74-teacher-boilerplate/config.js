import firebase from "firebase";

const firebaseConfig = {
  apiKey: "AIzaSyCumMQlfkb0k8bV9Gg3YJpLiHVfTbuy4aM",
  authDomain: "bookscanner-bd067.firebaseapp.com",
  projectId: "bookscanner-bd067",
  storageBucket: "bookscanner-bd067.appspot.com",
  messagingSenderId: "368910269666",
  appId: "1:368910269666:web:4821c31f7b0a5336fe72bb",
  measurementId: "G-WE855C3XMN"
};

firebase.initializeApp(firebaseConfig);

export default firebase.firestore();
